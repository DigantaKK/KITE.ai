# 🚀 KITE AI Installation Guide

## Quick Start (3 Steps)

### Step 1: Download
- Download this entire folder
- Extract the ZIP file

### Step 2: Install Dependencies
Open terminal/command prompt in the folder and run:
\`\`\`bash
npm install
\`\`\`

### Step 3: Run
\`\`\`bash
npm run dev
\`\`\`

Then open: http://localhost:3000

## Deploy to Internet (Free)

### Option A: Vercel (Recommended)
1. Go to https://vercel.com
2. Sign up with Google/GitHub
3. Click "New Project"
4. Upload this folder
5. Click "Deploy"
6. Get your URL in 2 minutes!

### Option B: Netlify
1. Go to https://netlify.com
2. Drag and drop this folder
3. Get instant URL!

## Mobile Installation
Once deployed:
- Android: Chrome → Menu → "Add to Home Screen"
- iPhone: Safari → Share → "Add to Home Screen"

## Support
Created by Diganta Kumar Das from Bangladesh 🇧🇩
