# KITE - Professional AI Assistant

A modern, professional AI chatbot application built with Next.js and integrated with OpenRouter API.

## 🚀 Features

- **Professional AI Chat Interface** - Clean, modern design with KITE branding
- **Multiple AI Models** - Support for GPT-4o, Claude, DeepSeek, and more
- **Session Management** - Create, save, and manage multiple chat sessions
- **Dark/Light Mode** - Automatic theme switching
- **Mobile Responsive** - Works perfectly on all devices
- **Markdown Support** - Rich text formatting in responses
- **Export Options** - Save conversations as PDF, TXT, or JSON
- **Real-time Messaging** - Instant responses with typing indicators

## 🛠️ Quick Start

### Prerequisites
- Node.js 18+ installed
- OpenRouter API key

### Installation

1. **Clone or download the project**
2. **Install dependencies:**
   \`\`\`bash
   npm install
   \`\`\`

3. **Start development server:**
   \`\`\`bash
   npm run dev
   \`\`\`

4. **Open your browser:**
   Navigate to `http://localhost:3000`

### Production Deployment

1. **Build the application:**
   \`\`\`bash
   npm run build
   \`\`\`

2. **Start production server:**
   \`\`\`bash
   npm start
   \`\`\`

## 🔧 Configuration

### API Setup
1. Open KITE in your browser
2. Click the Settings icon in the header
3. Go to the "General" tab
4. Enter your OpenRouter API key
5. Customize the system prompt if desired

### Model Selection
- Go to Settings > AI Model
- Choose from available models (DeepSeek R1, GPT-4o, Claude, etc.)
- Adjust temperature and max tokens as needed

## 📱 Usage

1. **Start Chatting:** Type your message and press Enter
2. **New Session:** Click the "+" button in the sidebar
3. **Switch Sessions:** Click on any chat in the sidebar
4. **Copy Messages:** Click the copy button on any KITE response
5. **Export Chat:** Use Settings > Export to save conversations

## 🌐 Deployment Options

### Vercel (Recommended)
1. Push code to GitHub
2. Connect to Vercel
3. Deploy automatically

### Netlify
1. Build the project: `npm run build`
2. Upload the `out` folder to Netlify

### Docker
\`\`\`dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
\`\`\`

## 🔒 Security

- API keys are stored locally in your browser
- No data is sent to external servers except OpenRouter
- All conversations are stored locally
- HTTPS recommended for production

## 🎨 Customization

### Branding
- Edit colors in `app/globals.css`
- Replace logo in header component
- Modify welcome message in `components/welcome-message.tsx`

### Models
- Add new models in `components/settings-modal.tsx`
- Update model list in the Select component

## 📞 Support

For issues or questions:
1. Check the browser console for errors
2. Verify your API key is correct
3. Ensure you have internet connectivity
4. Try refreshing the page

## 🚀 Features Roadmap

- [ ] Voice input/output
- [ ] File upload support
- [ ] Team collaboration
- [ ] Advanced analytics
- [ ] Custom model fine-tuning
- [ ] API rate limiting dashboard

## 📄 License

This project is licensed under the MIT License.

---

**KITE** - Your Professional AI Assistant
