import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "KITE AI - Premium AI Assistant",
  description:
    "Premium AI Assistant created by Diganta Kumar Das from Bangladesh. Fast, intelligent, and professional AI chat experience.",
  keywords: "AI, chatbot, assistant, artificial intelligence, KITE, Bangladesh, Diganta Kumar Das",
  authors: [{ name: "Diganta Kumar Das", url: "https://kite-ai.com" }],
  creator: "Diganta Kumar Das",
  publisher: "KITE Company",
  viewport: "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#3b82f6" },
    { media: "(prefers-color-scheme: dark)", color: "#1e40af" },
  ],
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "KITE AI",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    type: "website",
    siteName: "KITE AI",
    title: "KITE AI - Premium AI Assistant",
    description: "Premium AI Assistant created by Diganta Kumar Das from Bangladesh",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "KITE AI - Premium AI Assistant",
    description: "Premium AI Assistant created by Diganta Kumar Das from Bangladesh",
    creator: "@DigantaKumarDas",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/icon-192.png" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="KITE AI" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-TileColor" content="#3b82f6" />
        <meta name="msapplication-tap-highlight" content="no" />
      </head>
      <body className={inter.className}>{children}</body>
    </html>
  )
}
