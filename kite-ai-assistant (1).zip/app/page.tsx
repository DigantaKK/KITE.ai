"use client"

import { useState, Suspense } from "react"
import { ChatInterface } from "@/components/chat-interface"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { AuthModal } from "@/components/auth-modal"
import { SettingsModal } from "@/components/settings-modal"
import { ThemeProvider } from "@/components/theme-provider"
import { ChatProvider } from "@/contexts/chat-context"
import { AuthProvider } from "@/contexts/auth-context"
import { ErrorBoundary } from "@/components/error-boundary"
import { LoadingScreen } from "@/components/loading-screen"

export default function Home() {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [authModalOpen, setAuthModalOpen] = useState(false)
  const [settingsModalOpen, setSettingsModalOpen] = useState(false)

  return (
    <ErrorBoundary>
      <ThemeProvider>
        <AuthProvider>
          <ChatProvider>
            <Suspense fallback={<LoadingScreen />}>
              <div className="flex h-screen bg-background text-foreground">
                <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

                <div className="flex-1 flex flex-col">
                  <Header
                    onMenuClick={() => setSidebarOpen(true)}
                    onAuthClick={() => setAuthModalOpen(true)}
                    onSettingsClick={() => setSettingsModalOpen(true)}
                  />

                  <ChatInterface />
                </div>

                <AuthModal isOpen={authModalOpen} onClose={() => setAuthModalOpen(false)} />

                <SettingsModal isOpen={settingsModalOpen} onClose={() => setSettingsModalOpen(false)} />
              </div>
            </Suspense>
          </ChatProvider>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  )
}
