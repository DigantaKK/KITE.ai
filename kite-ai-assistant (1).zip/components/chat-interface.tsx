"use client"

import { useEffect, useRef } from "react"
import { MessageBubble } from "@/components/message-bubble"
import { InputArea } from "@/components/input-area"
import { WelcomeMessage } from "@/components/welcome-message"
import { TypingIndicator } from "@/components/typing-indicator"
import { useChat } from "@/contexts/chat-context"

export function ChatInterface() {
  const { messages, isLoading, isStreaming } = useChat()
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages, isLoading, isStreaming])

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <WelcomeMessage />
        ) : (
          messages.map((message) => <MessageBubble key={message.id} message={message} />)
        )}

        {(isLoading || isStreaming) && <TypingIndicator />}
        <div ref={messagesEndRef} />
      </div>

      <InputArea />
    </div>
  )
}
