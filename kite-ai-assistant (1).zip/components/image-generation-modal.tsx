"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useChat } from "@/contexts/chat-context"
import { ImageIcon, Sparkles, Palette, Camera, Zap } from "lucide-react"

interface ImageGenerationModalProps {
  isOpen: boolean
  onClose: () => void
}

export function ImageGenerationModal({ isOpen, onClose }: ImageGenerationModalProps) {
  const [prompt, setPrompt] = useState("")
  const [style, setStyle] = useState("realistic")
  const [size, setSize] = useState("1024x1024")
  const { generateImage, isLoading } = useChat()

  const handleGenerate = async () => {
    if (!prompt.trim()) return

    const fullPrompt = `${prompt}, ${style} style, high quality, detailed`
    await generateImage(fullPrompt, { size })
    onClose()
    setPrompt("")
  }

  const quickPrompts = [
    {
      icon: Camera,
      title: "KITE AI Logo",
      prompt: "Professional logo for KITE AI, modern tech design, blue and purple gradient, minimalist, vector style",
    },
    {
      icon: Palette,
      title: "Abstract Art",
      prompt: "Beautiful abstract digital art, colorful, flowing shapes, modern artistic style",
    },
    {
      icon: Sparkles,
      title: "Tech Landscape",
      prompt: "Futuristic technology landscape, AI elements, neon lights, cyberpunk style, high-tech city",
    },
    {
      icon: Zap,
      title: "Creative Design",
      prompt: "Creative modern design, geometric patterns, vibrant colors, professional artwork",
    },
  ]

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
              <ImageIcon className="h-4 w-4 text-white" />
            </div>
            Generate Image with KITE AI
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Quick Prompts */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Quick Prompts</Label>
            <div className="grid grid-cols-2 gap-2">
              {quickPrompts.map((item, index) => (
                <Button
                  key={index}
                  variant="outline"
                  className="h-auto p-3 justify-start text-left hover:bg-muted/50 bg-transparent"
                  onClick={() => setPrompt(item.prompt)}
                >
                  <div className="flex items-start gap-2">
                    <item.icon className="h-4 w-4 mt-0.5 text-primary" />
                    <div>
                      <div className="font-medium text-sm">{item.title}</div>
                      <div className="text-xs text-muted-foreground line-clamp-2">{item.prompt.slice(0, 50)}...</div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
          </div>

          {/* Custom Prompt */}
          <div className="space-y-2">
            <Label htmlFor="prompt">Describe your image</Label>
            <Textarea
              id="prompt"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to generate... (e.g., 'A beautiful sunset over mountains with a lake')"
              rows={3}
              className="resize-none"
            />
          </div>

          {/* Style Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Art Style</Label>
              <Select value={style} onValueChange={setStyle}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="realistic">Realistic</SelectItem>
                  <SelectItem value="artistic">Artistic</SelectItem>
                  <SelectItem value="cartoon">Cartoon</SelectItem>
                  <SelectItem value="abstract">Abstract</SelectItem>
                  <SelectItem value="minimalist">Minimalist</SelectItem>
                  <SelectItem value="cyberpunk">Cyberpunk</SelectItem>
                  <SelectItem value="watercolor">Watercolor</SelectItem>
                  <SelectItem value="oil painting">Oil Painting</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Image Size</Label>
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1024x1024">Square (1024x1024)</SelectItem>
                  <SelectItem value="1024x768">Landscape (1024x768)</SelectItem>
                  <SelectItem value="768x1024">Portrait (768x1024)</SelectItem>
                  <SelectItem value="1280x720">Wide (1280x720)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button
              onClick={handleGenerate}
              disabled={!prompt.trim() || isLoading}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            >
              {isLoading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Generating...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Generate Image
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
