"use client"

import type React from "react"
import { useState, useRef, type KeyboardEvent } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Send, Paperclip, Mic, Square, ImageIcon, Camera } from "lucide-react"
import { useChat } from "@/contexts/chat-context"
import { ImageGenerationModal } from "@/components/image-generation-modal"
import { FileUploadModal } from "@/components/file-upload-modal"

export function InputArea() {
  const [input, setInput] = useState("")
  const [showImageModal, setShowImageModal] = useState(false)
  const [showFileModal, setShowFileModal] = useState(false)
  const { sendMessage, isLoading, isStreaming, stopGeneration, generateImage } = useChat()
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleSubmit = async () => {
    if (!input.trim() || isLoading) return

    await sendMessage(input.trim())
    setInput("")

    if (textareaRef.current) {
      textareaRef.current.style.height = "auto"
    }
  }

  const handleStop = () => {
    stopGeneration()
  }

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSubmit()
    }
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)

    const textarea = e.target
    textarea.style.height = "auto"
    textarea.style.height = `${Math.min(textarea.scrollHeight, 200)}px`
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setShowFileModal(true)
    }
  }

  const quickImagePrompts = [
    "Generate a professional logo for KITE AI",
    "Create a beautiful landscape image",
    "Design a modern tech startup logo",
    "Generate a creative abstract art",
  ]

  return (
    <>
      <div className="border-t border-border bg-background/95 backdrop-blur-sm p-4">
        <div className="max-w-4xl mx-auto">
          {/* Quick Image Generation Buttons */}
          <div className="flex gap-2 mb-3 overflow-x-auto pb-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowImageModal(true)}
              className="flex items-center gap-2 whitespace-nowrap bg-gradient-to-r from-purple-500/10 to-pink-500/10 hover:from-purple-500/20 hover:to-pink-500/20 border-purple-300/30"
            >
              <ImageIcon className="h-4 w-4" />
              Generate Image
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => generateImage("Generate a professional logo for KITE AI with modern design")}
              className="flex items-center gap-2 whitespace-nowrap bg-gradient-to-r from-blue-500/10 to-cyan-500/10 hover:from-blue-500/20 hover:to-cyan-500/20 border-blue-300/30"
              disabled={isLoading}
            >
              <Camera className="h-4 w-4" />
              KITE Logo
            </Button>

            <Button
              variant="outline"
              size="sm"
              onClick={() => generateImage("Create a beautiful futuristic tech landscape with AI elements")}
              className="flex items-center gap-2 whitespace-nowrap bg-gradient-to-r from-green-500/10 to-emerald-500/10 hover:from-green-500/20 hover:to-emerald-500/20 border-green-300/30"
              disabled={isLoading}
            >
              <ImageIcon className="h-4 w-4" />
              Tech Art
            </Button>
          </div>

          <div className="flex items-end gap-2">
            <div className="flex-1 relative">
              <Textarea
                ref={textareaRef}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                placeholder="Message KITE AI... (Try: 'Generate an image of...' or upload a file)"
                className="min-h-[44px] max-h-[200px] resize-none pr-24 bg-background/50 backdrop-blur-sm border-2 focus:border-primary/50 transition-all duration-200"
                disabled={isLoading}
              />

              <div className="absolute right-2 bottom-2 flex gap-1">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  accept="image/*,.pdf,.txt,.doc,.docx"
                  className="hidden"
                />

                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-blue-500/10"
                  disabled={isLoading}
                  onClick={() => fileInputRef.current?.click()}
                  title="Upload File"
                >
                  <Paperclip className="h-4 w-4" />
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-green-500/10"
                  disabled={isLoading}
                  title="Voice Input (Coming Soon)"
                >
                  <Mic className="h-4 w-4" />
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  className="h-8 w-8 p-0 hover:bg-purple-500/10"
                  disabled={isLoading}
                  onClick={() => setShowImageModal(true)}
                  title="Generate Image"
                >
                  <ImageIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {isStreaming ? (
              <Button onClick={handleStop} className="h-11 px-4 bg-red-600 hover:bg-red-700 text-white shadow-lg">
                <Square className="h-4 w-4 mr-2" />
                Stop
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={!input.trim() || isLoading}
                className="h-11 px-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all duration-200"
              >
                <Send className="h-4 w-4" />
              </Button>
            )}
          </div>

          <p className="text-xs text-muted-foreground mt-2 text-center">
            Press Enter to send • Shift+Enter for new line • 🖼️ Generate images • 📎 Upload files • KITE AI by Diganta
            Kumar Das 🇧🇩
          </p>
        </div>
      </div>

      <ImageGenerationModal isOpen={showImageModal} onClose={() => setShowImageModal(false)} />

      <FileUploadModal isOpen={showFileModal} onClose={() => setShowFileModal(false)} />
    </>
  )
}
