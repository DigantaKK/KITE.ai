"use client"

import { cn } from "@/lib/utils"

interface KiteLogoProps {
  className?: string
  animate?: boolean
  isStreaming?: boolean
}

export function KiteLogo({ className, animate = false, isStreaming = false }: KiteLogoProps) {
  return (
    <div className={cn("relative", className)}>
      <svg
        viewBox="0 0 40 40"
        className={cn(
          "w-full h-full transition-all duration-300",
          animate && "animate-kite-dance",
          isStreaming && "animate-kite-streaming",
        )}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer glow effect */}
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          <linearGradient id="kite-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF6B6B" />
            <stop offset="25%" stopColor="#4ECDC4" />
            <stop offset="50%" stopColor="#45B7D1" />
            <stop offset="75%" stopColor="#96CEB4" />
            <stop offset="100%" stopColor="#FFEAA7" />
          </linearGradient>

          <linearGradient id="kite-gradient-2" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#667eea" />
            <stop offset="100%" stopColor="#764ba2" />
          </linearGradient>

          <radialGradient id="center-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>

        {/* Main kite body with extraordinary design */}
        <path
          d="M20 3L8 15L20 22L32 15L20 3Z"
          fill="url(#kite-gradient)"
          stroke="url(#kite-gradient-2)"
          strokeWidth="2"
          filter="url(#glow)"
          className="drop-shadow-lg"
        />

        {/* Inner diamond pattern */}
        <path d="M20 8L14 15L20 18L26 15L20 8Z" fill="url(#center-glow)" opacity="0.6" />

        {/* Cross lines with glow */}
        <line x1="8" y1="15" x2="32" y2="15" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />
        <line x1="20" y1="3" x2="20" y2="22" stroke="#ffffff" strokeWidth="1.5" opacity="0.8" />

        {/* Decorative corner dots */}
        <circle cx="20" cy="3" r="2" fill="#FFD93D" className="animate-pulse" />
        <circle cx="8" cy="15" r="1.5" fill="#6BCF7F" className="animate-pulse" style={{ animationDelay: "0.5s" }} />
        <circle cx="32" cy="15" r="1.5" fill="#4D96FF" className="animate-pulse" style={{ animationDelay: "1s" }} />
        <circle cx="20" cy="22" r="1.5" fill="#FF6B9D" className="animate-pulse" style={{ animationDelay: "1.5s" }} />

        {/* Kite tail with multiple segments */}
        <path
          d="M20 22L18 26L20 28L22 26L20 22Z"
          fill="url(#kite-gradient)"
          stroke="url(#kite-gradient-2)"
          strokeWidth="1"
        />

        <path
          d="M20 28L19 31L20 33L21 31L20 28Z"
          fill="url(#kite-gradient)"
          stroke="url(#kite-gradient-2)"
          strokeWidth="1"
        />

        {/* Kite string with animated dashes */}
        <line
          x1="20"
          y1="33"
          x2="20"
          y2="38"
          stroke="url(#kite-gradient-2)"
          strokeWidth="2"
          strokeDasharray="3,2"
          className="animate-pulse"
        />

        {/* Floating sparkles around kite */}
        <circle cx="12" cy="8" r="0.5" fill="#FFD93D" className="animate-ping" />
        <circle cx="28" cy="10" r="0.5" fill="#4D96FF" className="animate-ping" style={{ animationDelay: "0.3s" }} />
        <circle cx="30" cy="20" r="0.5" fill="#6BCF7F" className="animate-ping" style={{ animationDelay: "0.6s" }} />
        <circle cx="10" cy="22" r="0.5" fill="#FF6B9D" className="animate-ping" style={{ animationDelay: "0.9s" }} />
      </svg>
    </div>
  )
}
