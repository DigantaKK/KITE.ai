"use client"

import { Zap } from "lucide-react"

export function LoadingScreen() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-4 mx-auto animate-pulse">
          <Zap className="h-8 w-8 text-white" />
        </div>
        <h1 className="text-2xl font-bold mb-2">
          <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">KITE</span>
        </h1>
        <p className="text-muted-foreground">Loading your AI assistant...</p>
      </div>
    </div>
  )
}
