"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Copy, Check, User } from "lucide-react"
import type { Message } from "@/types/chat"
import ReactMarkdown from "react-markdown"
import { useTheme } from "next-themes"
import { KiteLogo } from "@/components/kite-logo"
import { useChat } from "@/contexts/chat-context"

interface MessageBubbleProps {
  message: Message
}

export function MessageBubble({ message }: MessageBubbleProps) {
  const [copied, setCopied] = useState(false)
  const { theme } = useTheme()
  const { isStreaming } = useChat()

  const copyToClipboard = async () => {
    await navigator.clipboard.writeText(message.content)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const formatTime = (timestamp: Date) => {
    return new Intl.DateTimeFormat("en-US", {
      hour: "2-digit",
      minute: "2-digit",
    }).format(timestamp)
  }

  const formatResponseTime = (responseTime?: number) => {
    if (!responseTime) return ""
    if (responseTime < 1000) return `${responseTime}ms`
    return `${(responseTime / 1000).toFixed(1)}s`
  }

  const isLastMessage = message.role === "assistant" && message.content === ""

  return (
    <div className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}>
      {message.role === "assistant" && (
        <div className="flex items-start justify-center w-8 h-8 rounded-full flex-shrink-0 mt-1">
          <KiteLogo
            className={`w-6 h-6 text-blue-500 transition-all duration-300 ${
              isStreaming && isLastMessage ? "animate-pulse-glow opacity-100" : "opacity-80 hover:opacity-100"
            }`}
            animate={isStreaming && isLastMessage}
          />
        </div>
      )}

      <div className={`max-w-[85%] ${message.role === "user" ? "order-2" : ""}`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            message.role === "user"
              ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white ml-auto shadow-lg"
              : "bg-muted/50 backdrop-blur-sm border border-border/50"
          }`}
        >
          {message.role === "assistant" ? (
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <ReactMarkdown
                components={{
                  code({ inline, className, children, ...props }) {
                    if (inline) {
                      return (
                        <code className="bg-primary/10 text-primary px-1.5 py-0.5 rounded text-sm font-mono" {...props}>
                          {children}
                        </code>
                      )
                    }
                    return (
                      <pre className="bg-muted border border-border rounded-lg p-4 overflow-x-auto my-2">
                        <code className="font-mono text-sm" {...props}>
                          {children}
                        </code>
                      </pre>
                    )
                  },
                  p({ children }) {
                    return <p className="mb-2 last:mb-0 leading-relaxed">{children}</p>
                  },
                  ul({ children }) {
                    return <ul className="list-disc list-inside space-y-1 mb-2">{children}</ul>
                  },
                  ol({ children }) {
                    return <ol className="list-decimal list-inside space-y-1 mb-2">{children}</ol>
                  },
                  blockquote({ children }) {
                    return (
                      <blockquote className="border-l-4 border-primary pl-4 italic text-muted-foreground my-2">
                        {children}
                      </blockquote>
                    )
                  },
                }}
              >
                {message.content || (isStreaming ? "..." : "")}
              </ReactMarkdown>
            </div>
          ) : (
            <p className="whitespace-pre-wrap leading-relaxed">{message.content}</p>
          )}
        </div>

        <div
          className={`flex items-center gap-2 mt-2 text-xs text-muted-foreground ${
            message.role === "user" ? "justify-end" : "justify-start"
          }`}
        >
          <span>{formatTime(message.timestamp)}</span>
          {message.responseTime && (
            <span className="text-green-600 dark:text-green-400 font-medium">
              • ⚡ {formatResponseTime(message.responseTime)}
            </span>
          )}
          {message.role === "assistant" && message.content && (
            <Button variant="ghost" size="sm" onClick={copyToClipboard} className="h-6 w-6 p-0 hover:bg-primary/10">
              {copied ? <Check className="h-3 w-3 text-green-600" /> : <Copy className="h-3 w-3" />}
            </Button>
          )}
        </div>
      </div>

      {message.role === "user" && (
        <div className="flex items-center justify-center w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex-shrink-0 mt-1">
          <User className="h-4 w-4 text-white" />
        </div>
      )}
    </div>
  )
}
