"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Plus, Search, MessageSquare, Trash2, X } from "lucide-react"
import { useChat } from "@/contexts/chat-context"
import type { ChatSession } from "@/types/chat"

interface SidebarProps {
  isOpen: boolean
  onClose: () => void
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const { sessions, currentSessionId, createNewSession, switchSession, deleteSession } = useChat()

  const filteredSessions = sessions.filter((session) => session.title.toLowerCase().includes(searchQuery.toLowerCase()))

  const handleNewChat = () => {
    createNewSession()
    onClose()
  }

  const handleSessionClick = (sessionId: string) => {
    switchSession(sessionId)
    onClose()
  }

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && <div className="fixed inset-0 bg-black/50 z-40 md:hidden" onClick={onClose} />}

      {/* Sidebar */}
      <div
        className={`
        fixed left-0 top-0 h-full w-80 bg-background border-r border-border z-50 transform transition-transform duration-300 ease-in-out
        md:relative md:translate-x-0 md:z-0
        ${isOpen ? "translate-x-0" : "-translate-x-full"}
      `}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h2 className="font-semibold">Chat History</h2>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={handleNewChat}>
                <Plus className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose} className="md:hidden">
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Search */}
          <div className="p-4 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Sessions */}
          <ScrollArea className="flex-1">
            <div className="p-2">
              {filteredSessions.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No conversations yet</p>
                </div>
              ) : (
                filteredSessions.map((session) => (
                  <SessionItem
                    key={session.id}
                    session={session}
                    isActive={session.id === currentSessionId}
                    onClick={() => handleSessionClick(session.id)}
                    onDelete={() => deleteSession(session.id)}
                  />
                ))
              )}
            </div>
          </ScrollArea>
        </div>
      </div>
    </>
  )
}

interface SessionItemProps {
  session: ChatSession
  isActive: boolean
  onClick: () => void
  onDelete: () => void
}

function SessionItem({ session, isActive, onClick, onDelete }: SessionItemProps) {
  const [showActions, setShowActions] = useState(false)

  return (
    <div
      className={`
        group relative rounded-lg p-3 mb-2 cursor-pointer transition-colors
        ${isActive ? "bg-primary/10 border border-primary/20" : "hover:bg-muted/50"}
      `}
      onClick={onClick}
      onMouseEnter={() => setShowActions(true)}
      onMouseLeave={() => setShowActions(false)}
    >
      <div className="flex items-start gap-3">
        <MessageSquare className="h-4 w-4 mt-0.5 flex-shrink-0 text-muted-foreground" />
        <div className="flex-1 min-w-0">
          <h3 className="font-medium text-sm truncate">{session.title}</h3>
          <p className="text-xs text-muted-foreground mt-1">{session.messages.length} messages</p>
          <p className="text-xs text-muted-foreground">
            {session.updatedAt instanceof Date && !isNaN(session.updatedAt.getTime())
              ? new Intl.DateTimeFormat("en-US", {
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                }).format(session.updatedAt)
              : "—"}
          </p>
        </div>
      </div>

      {showActions && (
        <div className="absolute right-2 top-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation()
              onDelete()
            }}
            className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
        </div>
      )}
    </div>
  )
}
