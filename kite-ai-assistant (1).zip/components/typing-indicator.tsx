"use client"

import { KiteLogo } from "@/components/kite-logo"
import { useChat } from "@/contexts/chat-context"

export function TypingIndicator() {
  const { isStreaming } = useChat()

  return (
    <div className="flex gap-3 justify-start">
      <div className="flex items-center justify-center w-10 h-10 rounded-full flex-shrink-0">
        <KiteLogo animate={true} isStreaming={isStreaming} className="w-8 h-8 text-blue-500" />
      </div>

      <div className="bg-gradient-to-r from-muted/50 to-muted/30 backdrop-blur-sm border border-border/50 rounded-2xl px-4 py-3 shadow-lg">
        <div className="flex items-center space-x-3">
          <div className="flex space-x-1">
            <div className="w-2.5 h-2.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
            <div className="w-2.5 h-2.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
            <div className="w-2.5 h-2.5 bg-gradient-to-r from-pink-500 to-red-500 rounded-full animate-bounce"></div>
          </div>
          <span className="text-sm text-muted-foreground font-medium bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            KITE AI is thinking...
          </span>
        </div>
      </div>
    </div>
  )
}
