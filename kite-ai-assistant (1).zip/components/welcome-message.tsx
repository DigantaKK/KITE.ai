"use client"

import { MessageCircle, Lightbulb, Code, FileText, Sparkles, Crown, ImageIcon, Upload } from "lucide-react"
import { Card } from "@/components/ui/card"
import { useChat } from "@/contexts/chat-context"
import { KiteLogo } from "@/components/kite-logo"

const suggestions = [
  {
    icon: MessageCircle,
    title: "Start a conversation",
    description: "Ask me anything you'd like to know",
    prompt: "Hello KITE! Can you tell me about yourself and who created you?",
  },
  {
    icon: ImageIcon,
    title: "Generate images",
    description: "Create beautiful AI-generated images",
    prompt: "Generate a beautiful futuristic cityscape with neon lights",
  },
  {
    icon: Upload,
    title: "Upload & analyze files",
    description: "Upload documents, images, or data files",
    prompt: "I want to upload a file for analysis",
  },
  {
    icon: Code,
    title: "Code assistance",
    description: "Get help with programming tasks",
    prompt: "Can you help me write a Python function with best practices?",
  },
  {
    icon: Lightbulb,
    title: "Creative ideas",
    description: "Brainstorm solutions and concepts",
    prompt: "Help me brainstorm innovative ideas for a tech startup",
  },
  {
    icon: FileText,
    title: "Write content",
    description: "Create articles, emails, and more",
    prompt: "Help me write a professional business proposal",
  },
]

export function WelcomeMessage() {
  const { sendMessage, generateImage } = useChat()

  const handleSuggestionClick = (prompt: string) => {
    if (prompt.includes("upload a file")) {
      // This will be handled by the file upload modal
      return
    }
    if (prompt.includes("Generate a beautiful")) {
      generateImage("beautiful futuristic cityscape with neon lights, cyberpunk style, high quality")
      return
    }
    sendMessage(prompt)
  }

  return (
    <div className="flex flex-col items-center justify-center h-full max-w-5xl mx-auto p-8">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center w-24 h-24 mb-6 mx-auto relative">
          <KiteLogo className="w-full h-full text-blue-500 animate-float" />
          <div className="absolute -top-2 -right-2">
            <Crown className="h-6 w-6 text-yellow-500 animate-pulse" />
          </div>
        </div>

        <h1 className="text-4xl font-bold mb-3">
          Hello! I'm{" "}
          <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
            KITE AI
          </span>
        </h1>

        <p className="text-lg text-muted-foreground mb-2">Your Premium AI Assistant</p>

        <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-4">
          <Sparkles className="h-4 w-4 text-yellow-500" />
          <span>Created by Diganta Kumar Das • KITE Company • Bangladesh</span>
        </div>

        <div className="bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 rounded-lg p-3 mb-8">
          <p className="text-sm text-muted-foreground">
            🚀 Fast responses • 🎨 Image generation • 📎 File analysis • 🇧🇩 Made in Bangladesh
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-4xl">
        {suggestions.map((suggestion, index) => (
          <Card
            key={index}
            className="p-4 cursor-pointer hover:bg-muted/50 hover:border-primary/20 transition-all duration-200 hover:shadow-lg hover:scale-[1.02] group border-2 hover:border-gradient-to-r hover:from-blue-500/20 hover:to-purple-500/20"
            onClick={() => handleSuggestionClick(suggestion.prompt)}
          >
            <div className="flex items-start gap-3">
              <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-lg flex-shrink-0 group-hover:from-blue-500/20 group-hover:to-purple-500/20 transition-colors">
                <suggestion.icon className="h-5 w-5 text-primary" />
              </div>

              <div>
                <h3 className="font-medium mb-1 group-hover:text-primary transition-colors">{suggestion.title}</h3>
                <p className="text-sm text-muted-foreground">{suggestion.description}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <div className="mt-8 text-center">
        <p className="text-sm text-muted-foreground">
          KITE AI - Proudly developed by <span className="font-semibold text-primary">Diganta Kumar Das</span> from
          Bangladesh 🇧🇩
        </p>
        <p className="text-xs text-muted-foreground mt-1">© 2024 KITE Company. All rights reserved.</p>
      </div>
    </div>
  )
}
