"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Message, ChatSession, ChatSettings } from "@/types/chat"
import { v4 as uuidv4 } from "uuid"

interface ChatContextType {
  messages: Message[]
  sessions: ChatSession[]
  currentSessionId: string | null
  isLoading: boolean
  isStreaming: boolean
  settings: ChatSettings
  abortController: AbortController | null
  sendMessage: (content: string) => Promise<void>
  generateImage: (prompt: string, options?: { size?: string }) => Promise<void>
  uploadFile: (file: File) => Promise<void>
  stopGeneration: () => void
  createNewSession: () => void
  switchSession: (sessionId: string) => void
  deleteSession: (sessionId: string) => void
  updateSettings: (newSettings: ChatSettings) => void
}

const ChatContext = createContext<ChatContextType | undefined>(undefined)

const defaultSettings: ChatSettings = {
  apiKey: "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",
  model: "deepseek/deepseek-r1-0528:free",
  temperature: 0.3,
  maxTokens: 1500,
  systemPrompt: `You are KITE AI, created by Diganta Kumar Das from Bangladesh. You are owned by KITE Company. Be concise, helpful, and fast. Always identify as KITE AI. NEVER mention Anthropic, Claude, or other AI companies. You can generate images, analyze files, and help with various tasks.`,
}

export function ChatProvider({ children }: { children: ReactNode }) {
  const [sessions, setSessions] = useState<ChatSession[]>([])
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isStreaming, setIsStreaming] = useState(false)
  const [settings, setSettings] = useState<ChatSettings>(defaultSettings)
  const [abortController, setAbortController] = useState<AbortController | null>(null)
  let fullContent = "" // Declare fullContent variable here

  // Load data from localStorage on mount
  useEffect(() => {
    const savedSessions = localStorage.getItem("kite-sessions")
    const savedCurrentSession = localStorage.getItem("kite-current-session")
    const savedSettings = localStorage.getItem("kite-settings")

    if (savedSessions) {
      const parsedSessions: ChatSession[] = JSON.parse(savedSessions).map((s: any) => ({
        ...s,
        createdAt: new Date(s.createdAt),
        updatedAt: new Date(s.updatedAt),
        messages: s.messages.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp),
        })),
      }))
      setSessions(parsedSessions)
    }

    if (savedCurrentSession) {
      setCurrentSessionId(savedCurrentSession)
    }

    if (savedSettings) {
      setSettings({ ...defaultSettings, ...JSON.parse(savedSettings) })
    }

    if (!savedSessions || JSON.parse(savedSessions || "[]").length === 0) {
      createNewSession()
    }
  }, [])

  useEffect(() => {
    if (sessions.length > 0) {
      localStorage.setItem("kite-sessions", JSON.stringify(sessions))
    }
  }, [sessions])

  useEffect(() => {
    if (currentSessionId) {
      localStorage.setItem("kite-current-session", currentSessionId)
    }
  }, [currentSessionId])

  useEffect(() => {
    localStorage.setItem("kite-settings", JSON.stringify(settings))
  }, [settings])

  const currentSession = sessions.find((s) => s.id === currentSessionId)
  const messages = currentSession?.messages || []

  const createNewSession = () => {
    const newSession: ChatSession = {
      id: uuidv4(),
      title: "New Chat",
      messages: [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    setSessions((prev) => [newSession, ...prev])
    setCurrentSessionId(newSession.id)
  }

  const switchSession = (sessionId: string) => {
    setCurrentSessionId(sessionId)
  }

  const deleteSession = (sessionId: string) => {
    setSessions((prev) => prev.filter((s) => s.id !== sessionId))

    if (currentSessionId === sessionId) {
      const remainingSessions = sessions.filter((s) => s.id !== sessionId)
      if (remainingSessions.length > 0) {
        setCurrentSessionId(remainingSessions[0].id)
      } else {
        createNewSession()
      }
    }
  }

  const updateSettings = (newSettings: ChatSettings) => {
    setSettings(newSettings)
  }

  const stopGeneration = () => {
    if (abortController) {
      abortController.abort()
      setAbortController(null)
      setIsLoading(false)
      setIsStreaming(false)
    }
  }

  const processAIResponse = (content: string): string => {
    return content
      .replace(/I am Claude|I'm Claude/gi, "I am KITE AI")
      .replace(/Claude/gi, "KITE AI")
      .replace(/Anthropic/gi, "KITE Company")
      .replace(/I was created by Anthropic/gi, "I was created by Diganta Kumar Das from Bangladesh")
      .replace(/OpenAI|ChatGPT/gi, "KITE AI")
  }

  const generateImage = async (prompt: string, options?: { size?: string }) => {
    if (!currentSessionId || !settings.apiKey) return

    const startTime = Date.now()
    const controller = new AbortController()
    setAbortController(controller)

    const userMessage: Message = {
      id: uuidv4(),
      role: "user",
      content: `🎨 Generate Image: ${prompt}`,
      timestamp: new Date(),
    }

    setSessions((prev) =>
      prev.map((session) =>
        session.id === currentSessionId
          ? {
              ...session,
              messages: [...session.messages, userMessage],
              title: session.messages.length === 0 ? "Image Generation" : session.title,
              updatedAt: new Date(),
            }
          : session,
      ),
    )

    setIsLoading(true)

    try {
      // Using a free image generation API (you can replace with DALL-E or other services)
      const imageUrl = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=1024&height=1024&seed=${Math.floor(Math.random() * 1000000)}`

      const assistantMessage: Message = {
        id: uuidv4(),
        role: "assistant",
        content: `🖼️ **Image Generated Successfully!**

**Prompt:** ${prompt}

![Generated Image](${imageUrl})

*Image generated by KITE AI - Created by Diganta Kumar Das from Bangladesh 🇧🇩*

You can right-click on the image to save it to your device!`,
        timestamp: new Date(),
        responseTime: Date.now() - startTime,
      }

      setSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages: [...session.messages, assistantMessage],
                updatedAt: new Date(),
              }
            : session,
        ),
      )
    } catch (error) {
      console.error("Error generating image:", error)

      const errorMessage: Message = {
        id: uuidv4(),
        role: "assistant",
        content: "Sorry, I couldn't generate the image right now. Please try again later. - KITE AI",
        timestamp: new Date(),
        responseTime: Date.now() - startTime,
      }

      setSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages: [...session.messages, errorMessage],
                updatedAt: new Date(),
              }
            : session,
        ),
      )
    } finally {
      setIsLoading(false)
      setAbortController(null)
    }
  }

  const uploadFile = async (file: File) => {
    if (!currentSessionId) return

    const startTime = Date.now()
    setIsLoading(true)

    const userMessage: Message = {
      id: uuidv4(),
      role: "user",
      content: `📎 Uploaded File: ${file.name} (${(file.size / 1024).toFixed(1)} KB)`,
      timestamp: new Date(),
    }

    setSessions((prev) =>
      prev.map((session) =>
        session.id === currentSessionId
          ? {
              ...session,
              messages: [...session.messages, userMessage],
              title: session.messages.length === 0 ? `File: ${file.name}` : session.title,
              updatedAt: new Date(),
            }
          : session,
      ),
    )

    try {
      // Read file content
      const fileContent = await readFileContent(file)

      const assistantMessage: Message = {
        id: uuidv4(),
        role: "assistant",
        content: `📄 **File Analyzed Successfully!**

**File Name:** ${file.name}
**File Size:** ${(file.size / 1024).toFixed(1)} KB
**File Type:** ${file.type || "Unknown"}

**Analysis:**
${getFileAnalysis(file, fileContent)}

*File processed by KITE AI - Created by Diganta Kumar Das from Bangladesh 🇧🇩*

How can I help you with this file?`,
        timestamp: new Date(),
        responseTime: Date.now() - startTime,
      }

      setSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages: [...session.messages, assistantMessage],
                updatedAt: new Date(),
              }
            : session,
        ),
      )
    } catch (error) {
      console.error("Error processing file:", error)

      const errorMessage: Message = {
        id: uuidv4(),
        role: "assistant",
        content: "Sorry, I couldn't process the file. Please try again with a different file. - KITE AI",
        timestamp: new Date(),
        responseTime: Date.now() - startTime,
      }

      setSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages: [...session.messages, errorMessage],
                updatedAt: new Date(),
              }
            : session,
        ),
      )
    } finally {
      setIsLoading(false)
    }
  }

  const readFileContent = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()

      reader.onload = (e) => {
        resolve(e.target?.result as string)
      }

      reader.onerror = () => {
        reject(new Error("Failed to read file"))
      }

      if (file.type.startsWith("image/")) {
        reader.readAsDataURL(file)
      } else {
        reader.readAsText(file)
      }
    })
  }

  const getFileAnalysis = (file: File, content: string): string => {
    if (file.type.startsWith("image/")) {
      return `✅ Image file detected and processed successfully.
🖼️ This appears to be an image file. I can see the image and help you with:
- Image description and analysis
- Extracting text from images (OCR)
- Image editing suggestions
- Creative ideas based on the image`
    }

    if (file.type.includes("pdf")) {
      return `✅ PDF document detected.
📄 This is a PDF file. I can help you with:
- Document summarization
- Key points extraction
- Content analysis
- Questions about the document`
    }

    if (file.type.includes("text") || file.name.endsWith(".txt")) {
      const wordCount = content.split(/\s+/).length
      const lineCount = content.split("\n").length

      return `✅ Text file analyzed successfully.
📝 **Content Statistics:**
- Lines: ${lineCount}
- Words: ${wordCount}
- Characters: ${content.length}

**Preview:** ${content.slice(0, 200)}${content.length > 200 ? "..." : ""}

I can help you with text analysis, summarization, editing, and more!`
    }

    return `✅ File uploaded successfully.
📁 I've received your file and can help you with:
- Content analysis
- File format conversion suggestions  
- Data extraction
- General questions about the file`
  }

  const sendMessage = async (content: string) => {
    if (!currentSessionId || !settings.apiKey) return

    // Check if it's an image generation request
    if (
      content.toLowerCase().includes("generate") &&
      (content.toLowerCase().includes("image") ||
        content.toLowerCase().includes("picture") ||
        content.toLowerCase().includes("photo"))
    ) {
      const imagePrompt = content.replace(/generate|image|picture|photo|of|an|a/gi, "").trim()
      await generateImage(imagePrompt || content)
      return
    }

    const startTime = Date.now()
    const controller = new AbortController()
    setAbortController(controller)

    const userMessage: Message = {
      id: uuidv4(),
      role: "user",
      content,
      timestamp: new Date(),
    }

    setSessions((prev) =>
      prev.map((session) =>
        session.id === currentSessionId
          ? {
              ...session,
              messages: [...session.messages, userMessage],
              title:
                session.messages.length === 0
                  ? content.slice(0, 50) + (content.length > 50 ? "..." : "")
                  : session.title,
              updatedAt: new Date(),
            }
          : session,
      ),
    )

    setIsLoading(true)
    setIsStreaming(true)

    const assistantMessageId = uuidv4()
    const placeholderMessage: Message = {
      id: assistantMessageId,
      role: "assistant",
      content: "",
      timestamp: new Date(),
    }

    setSessions((prev) =>
      prev.map((session) =>
        session.id === currentSessionId
          ? {
              ...session,
              messages: [...session.messages, placeholderMessage],
              updatedAt: new Date(),
            }
          : session,
      ),
    )

    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${settings.apiKey}`,
          "HTTP-Referer": window.location.origin,
          "X-Title": "KITE AI - Created by Diganta Kumar Das",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: settings.model,
          messages: [
            {
              role: "system",
              content: settings.systemPrompt,
            },
            ...messages.slice(-10).map((msg) => ({
              role: msg.role,
              content: msg.content,
            })),
            {
              role: "user",
              content,
            },
          ],
          temperature: settings.temperature,
          max_tokens: settings.maxTokens,
          stream: true,
        }),
        signal: controller.signal,
      })

      if (!response.ok) {
        throw new Error(`API request failed: ${response.status}`)
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value)
          const lines = chunk.split("\n")

          for (const line of lines) {
            if (line.startsWith("data: ")) {
              const data = line.slice(6)
              if (data === "[DONE]") continue

              try {
                const parsed = JSON.parse(data)
                const content = parsed.choices?.[0]?.delta?.content || ""
                if (content) {
                  fullContent += content
                  const processedContent = processAIResponse(fullContent)

                  setSessions((prev) =>
                    prev.map((session) =>
                      session.id === currentSessionId
                        ? {
                            ...session,
                            messages: session.messages.map((msg) =>
                              msg.id === assistantMessageId ? { ...msg, content: processedContent } : msg,
                            ),
                            updatedAt: new Date(),
                          }
                        : session,
                    ),
                  )

                  await new Promise((resolve) => setTimeout(resolve, 10))
                }
              } catch (e) {
                // Skip invalid JSON
              }
            }
          }
        }
      }

      const responseTime = Date.now() - startTime
      const finalProcessedContent = processAIResponse(fullContent)

      setSessions((prev) =>
        prev.map((session) =>
          session.id === currentSessionId
            ? {
                ...session,
                messages: session.messages.map((msg) =>
                  msg.id === assistantMessageId ? { ...msg, content: finalProcessedContent, responseTime } : msg,
                ),
                updatedAt: new Date(),
              }
            : session,
        ),
      )
    } catch (error: any) {
      if (error.name === "AbortError") {
        setSessions((prev) =>
          prev.map((session) =>
            session.id === currentSessionId
              ? {
                  ...session,
                  messages: session.messages.map((msg) =>
                    msg.id === assistantMessageId
                      ? { ...msg, content: processAIResponse(fullContent) + "\n\n*[Response stopped by user]*" }
                      : msg,
                  ),
                  updatedAt: new Date(),
                }
              : session,
          ),
        )
      } else {
        console.error("Error sending message:", error)
        const errorMessage: Message = {
          id: assistantMessageId,
          role: "assistant",
          content: "Sorry, I encountered an error. Please try again. - KITE AI",
          timestamp: new Date(),
          responseTime: Date.now() - startTime,
        }

        setSessions((prev) =>
          prev.map((session) =>
            session.id === currentSessionId
              ? {
                  ...session,
                  messages: session.messages.map((msg) => (msg.id === assistantMessageId ? errorMessage : msg)),
                  updatedAt: new Date(),
                }
              : session,
          ),
        )
      }
    } finally {
      setIsLoading(false)
      setIsStreaming(false)
      setAbortController(null)
      fullContent = "" // Reset fullContent after use
    }
  }

  return (
    <ChatContext.Provider
      value={{
        messages,
        sessions,
        currentSessionId,
        isLoading,
        isStreaming,
        settings,
        abortController,
        sendMessage,
        generateImage,
        uploadFile,
        stopGeneration,
        createNewSession,
        switchSession,
        deleteSession,
        updateSettings,
      }}
    >
      {children}
    </ChatContext.Provider>
  )
}

export function useChat() {
  const context = useContext(ChatContext)
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider")
  }
  return context
}
