#!/bin/bash
echo "🚀 Deploying KITE AI..."
echo "📦 Installing dependencies..."
npm install

echo "🔨 Building application..."
npm run build

echo "✅ Ready for deployment!"
echo "🌐 Visit: https://vercel.com/new to deploy"
echo "📱 Your KITE AI will be live in 2 minutes!"
