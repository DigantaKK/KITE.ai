#!/bin/bash
echo "🚀 KITE AI Quick Setup"
echo ""
echo "Installing dependencies..."
npm install
echo ""
echo "Starting development server..."
echo "Open http://localhost:3000 in your browser"
echo ""
npm run dev
