export interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  responseTime?: number
}

export interface ChatSession {
  id: string
  title: string
  messages: Message[]
  createdAt: Date
  updatedAt: Date
}

export interface ChatSettings {
  apiKey: string
  model: string
  temperature: number
  maxTokens: number
  systemPrompt: string
}
